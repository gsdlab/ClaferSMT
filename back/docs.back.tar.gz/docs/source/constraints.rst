constraints Package
===================

:mod:`BracketedConstraint` Module
---------------------------------

.. automodule:: constraints.BracketedConstraint
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`Constraints` Module
-------------------------

.. automodule:: constraints.Constraints
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`IsomorphismConstraint` Module
-----------------------------------

.. automodule:: constraints.IsomorphismConstraint
    :members:
    :undoc-members:
    :show-inheritance:

