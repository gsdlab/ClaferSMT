constraints Package
===================

Description
-----------
Store information about various types of constraints, and generate the corresponding Z3 input.

:mod:`BracketedConstraint` Module
---------------------------------

.. automodule:: constraints.BracketedConstraint
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`CardinalityConstraint` Module
-----------------------------------

.. automodule:: constraints.CardinalityConstraint
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`Constraint` Module
------------------------

.. automodule:: constraints.Constraint
    :members:
    :undoc-members:
    :show-inheritance:

